<?php
class Book {
    public $title;
    public $author;
    public $year;
    public $isAvailable;

    public function __construct($title, $author, $year, $isAvailable = true) {
        $this->title = $title;
        $this->author = $author;
        $this->year = $year;
        $this->isAvailable = $isAvailable;
    }
}
?>
