<?php
class Reader {
    public $name;
    public $email;
    public $borrowedBooks = [];

    public function __construct($name, $email) {
        $this->name = $name;
        $this->email = $email;
    }

    public function borrowBook($book) {
        if ($book->isAvailable) {
            $this->borrowedBooks[] = $book;
            $book->isAvailable = false; 
        } else {
            echo "Книга '{$book->title}' недоступна.<br>";
        }
    }
}
?>
