<?php
class Library {
    public $books = [];

    public function addBook($book) {
        $this->books[] = $book;
    }

    public function listBooks() {
        foreach ($this->books as $book) {
            echo "{$book->title} - {$book->author}" . ($book->isAvailable ? "" : " (Нет)") . "<br>";
        }
    }
}
?>
